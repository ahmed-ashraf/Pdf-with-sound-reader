<?php
$link=mysqli_connect("localhost", "root", "");
mysqli_select_db($link,"databaseimage");
$sql = "SELECT image FROM store WHERE id=1";
$result = mysqli_query($link,"$sql");
header("Content-type: image/jpeg");
//echo $result;
$row=mysqli_fetch_assoc($result);
echo $row['image'];
mysqli_close($link);
?>