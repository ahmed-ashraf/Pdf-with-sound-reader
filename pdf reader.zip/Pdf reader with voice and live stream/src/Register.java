import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


public  class Register extends JFrame{
		
	 JLabel RegisterHeading = new JLabel("Registration");
	 TextField Name = new TextField();
	 TextField Password = new TextField();
	 JLabel LableName = new JLabel("Name");
	 JLabel LablePassword = new JLabel("Password");
	 JButton Submit = new JButton( "Save" );
	 JButton Cancel = new JButton( "Cancel" );
	 
		public Register(){
			super( "Note" );
			setLayout(null);
			
			 RegisterHeading.setBounds(270,30,400,26);
			 RegisterHeading.setForeground(Color.WHITE);
			 RegisterHeading.setFont(new Font("andalus", Font.PLAIN, 26));
			add(RegisterHeading);
			
			LableName.setBounds(20,150,100,25);
			LableName.setForeground(Color.WHITE);
			LableName.setFont(new Font("andalus", Font.PLAIN, 18));
			add(LableName);
			
			LablePassword.setBounds(20,200,100,25);
			LablePassword.setForeground(Color.WHITE);
			LablePassword.setFont(new Font("andalus", Font.PLAIN, 18));
			add(LablePassword);
			
			Name.setBounds(150,150,200,25);
			Name.setForeground(Color.black);
			Name.setFont(new Font("andalus", Font.PLAIN, 18));
			add(Name);
			
			Password.setBounds(150,200,200,25);
			Password.setForeground(Color.black);
			Password.setFont(new Font("andalus", Font.PLAIN, 18));
			add(Password);
			
			
			 
			Submit.setBounds(115,320,120,35);
			Submit.setBackground(new Color(95,95,95));
			Submit.setForeground(Color.WHITE);
			Submit.setFont(new Font("andalus", Font.PLAIN, 24));
			add(Submit);
			 
			Cancel.setBounds(335,320,120,35);
			Cancel.setBackground(new Color(95,95,95));
			Cancel.setForeground(Color.WHITE);
			Cancel.setFont(new Font("andalus", Font.PLAIN, 24));
			add(Cancel);

			 getContentPane().setBackground(Color.DARK_GRAY);
				
			Submit.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent arg0) {
				if(LocalConnection.SetUser(Name.getText(), Password.getText()))JOptionPane.showMessageDialog(null ,"Data Completly Saved" );
				
				else JOptionPane.showMessageDialog(null ,"This User Exist !! " );
				dispose();
				}});
				
			Cancel.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent arg0) {
				dispose();
			}});
					
			
		}
		}