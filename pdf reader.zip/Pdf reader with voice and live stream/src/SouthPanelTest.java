import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.Test;

public class SouthPanelTest {

	@Test
	public void nextPageBtnTest() {
		MainFrame window = new MainFrame();
		UIActions a = UIActions.getInstance();
		a.file = new File("C:\\Users\\ahmed\\Desktop\\docmentation.pdf");
		for (int i = 0; i < 5; i++) {
			a.viewNextPage();
		}
		// assertEquals(window.nPanel.textField.getText(), "10");
		assertEquals(a.pageNum, 5);
	}

	@Test
	public void previosPageTest() {
		MainFrame window = new MainFrame();
		UIActions a = UIActions.getInstance();
		a.file = new File("C:\\Users\\ahmed\\Desktop\\docmentation.pdf");
		a.viewLastPage();
		System.out.println(a.pageNum);
		assertEquals(a.pageNum, 4);
	}

}
