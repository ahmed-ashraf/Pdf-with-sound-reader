import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Abdulrahman Afify
 */
public class LocalConnectionTest {
    
    public LocalConnectionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of SetBook method, of class LocalConnection.
     */
    @Test
    public void testSetBook_String_String() {
        System.out.println("SetBook");
        String BookName = "abdo";
        String BookPath = "abdoafifi";
        boolean expResult = true;
        boolean result = LocalConnection.SetBook(BookName, BookPath);
        assertEquals(expResult, result);
       
    }

    /**
     * Test of SetBook method, of class LocalConnection.
     */
    @Test
    public void testSetBook_int_int() {
        System.out.println("SetBook");
        int UserID = 0;
        int BookID = 500000;
        boolean expResult = true;
        boolean result = LocalConnection.SetBook(UserID, BookID);
        assertEquals(expResult, result);
       
    }
 /**
     * Test of SetUser method, of class LocalConnection.
     */
    @Test
    public void testSetUser() {
        System.out.println("SetUser");
        String User = "davdavca";
        String Pass = "hossam";
       // String Question = "";
        //String Answer = "";
        boolean expResult = true;
        boolean result = LocalConnection.SetUser(User, Pass);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of SetNote method, of class LocalConnection.
     */
    @Test
    public void testSetNote() {
        System.out.println("SetNote");
        int UserID = 1;
        int BookID = 1;
        int PageNumber = 1;
        String Heading = "yes";
        String Note = "no";
        boolean expResult = true;
        boolean result = LocalConnection.SetNote(UserID, BookID, PageNumber, Heading, Note);
        assertEquals(expResult, result);
        
    }
 /**
     * Test of GetUser method, of class LocalConnection.
     */
    @Test
    public void testGetUser_String() {
        System.out.println("GetUser");
        //String Name = "";
        //LocalConnection.Row expResult;
        String result = LocalConnection.GetUser("Hossam").Password;
        assertEquals("12Gadget", result);
        
    }
    /**
     * Test of GetBook method, of class LocalConnection.
     */
    @Test
    public void testGetBook_String() {
        System.out.println("GetBook");
        String BookName = "abdo";
        int expResult = 31;
        int result = LocalConnection.GetBook(BookName);
        assertEquals(expResult, result);
       
    }

    /**
     * Test of GetNotes method, of class LocalConnection.
     */
    @Test
    public void testGetNotes() {
        System.out.println("GetNotes");
        int UserID = 0;
        int BookID = 0;
        int PageNumber = 0;
        boolean expResult=true;
        boolean result= LocalConnection.GetNotes(UserID, BookID, PageNumber);
        assertEquals(expResult,result);
      
    }
/**
     * Test of GetNote method, of class LocalConnection.
     */
    @Test
    public void testGetNote() {
        System.out.println("GetNote");
        int UserID = 0;
        int BookID = 0;
        int PageNumber = 0;
        String Heading = "";
        String expResult = "";
        String result = LocalConnection.GetNote(UserID, BookID, PageNumber, Heading);
        assertEquals(expResult, result);
       
    }
    /**
     * Test of GetBook method, of class LocalConnection.
     */
    @Test
    public void testGetBook_int() {
        System.out.println("GetBook");
        int ID = 14;
        boolean expResult = true;
        boolean result = LocalConnection.GetBook(ID).isEmpty();
        assertEquals(expResult, result);
       
    }


    /**
     * Test of GetBookName method, of class LocalConnection.
     */
    @Test
    public void testGetBookName() {
        System.out.println("GetBookName");
        String Path = "C:\\Users\\HossamOsama\\Downloads\\Documents\\6 xerox.pdf";
        String expResult = "6 xerox.pdf";
        String result = LocalConnection.GetBookName(Path);
        assertEquals(expResult, result);
       
    }

    /**
     * Test of GetBookPath method, of class LocalConnection.
     */
    @Test
    public void testGetBookPath() {
        System.out.println("GetBookPath");
        String BookName = "6 xerox.pdf";
        String expResult = "C:\\Users\\HossamOsama\\Downloads\\Documents\\6 xerox.pdf";
        String result = LocalConnection.GetBookPath(BookName);
        assertEquals(expResult, result);
       
    }
   
   
    
}
