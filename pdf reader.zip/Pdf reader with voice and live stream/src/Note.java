import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public  class Note extends JFrame{
		
	 JLabel RegisterHeading = new JLabel("Note");
	 TextField NoteHeadline = new TextField();
	 TextArea Note = new TextArea();
	 JButton Submit = new JButton( "Save" );
	 JButton Cancel = new JButton( "Cancel" );
	 
		public Note(){
			super( "Note" );
			setLayout(null);
			
			 RegisterHeading.setBounds(270,30,400,26);
			 RegisterHeading.setForeground(Color.WHITE);
			 RegisterHeading.setFont(new Font("andalus", Font.PLAIN, 26));
			add(RegisterHeading);
			
			NoteHeadline.setBounds(20,50,200,20);
			NoteHeadline.setForeground(Color.black);
			NoteHeadline.setFont(new Font("andalus", Font.PLAIN, 12));
			add(NoteHeadline);
			
			Note.setBounds(20,100,540,200);
			Note.setForeground(Color.black);
			Note.setFont(new Font("andalus", Font.PLAIN, 18));
			add(Note);
			
			
			 
			Submit.setBounds(115,320,120,35);
			Submit.setBackground(new Color(95,95,95));
			Submit.setForeground(Color.WHITE);
			Submit.setFont(new Font("andalus", Font.PLAIN, 24));
			add(Submit);
			 
			Cancel.setBounds(335,320,120,35);
			Cancel.setBackground(new Color(95,95,95));
			Cancel.setForeground(Color.WHITE);
			Cancel.setFont(new Font("andalus", Font.PLAIN, 24));
			add(Cancel);

			 getContentPane().setBackground(Color.DARK_GRAY);
				
			Submit.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent arg0) {
				LocalConnection.SetNote(LocalConnection.UserID, LocalConnection.BookID, UIActions.pageNum,NoteHeadline.getText() ,Note.getText());
				dispose();
				}});
				
			Cancel.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent arg0) {
				dispose();
			}});
					
			
		}
		}