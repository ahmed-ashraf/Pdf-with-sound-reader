import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Observable;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JSlider;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.bouncycastle.jce.provider.JDKDSASigner.stdDSA;


public class UIActions extends Observable{
	
	private static UIActions instance = null;
	
	static ArrayList<String> Notes ;
	static int pageNum = 0;
	Thread speakingThread;
	boolean isSpeaking = false;
	Speaker speaker;
	int numOfPages = 0;
	File file;
	public static String BookName;
	static DefaultListModel listModel = new DefaultListModel();
	private UIActions(){}
	public static synchronized UIActions getInstance() {
	      if(instance == null) {
	         instance = new UIActions();
	      }
	      return instance;
	}
	public int openFile(String path){
		try {
			pageNum = 0;
			file = new File(path);
			MainFrame.image = new PdfHandler().convertPDFToJPG(file.toString(),0);
			ImageIcon icon = new ImageIcon(MainFrame.image);
			MainFrame.label.setIcon(icon);
			//Files.files.add(file.toString());
			BookName = LocalConnection.GetBookName(file.getAbsolutePath());
			LocalConnection.BookID = LocalConnection.GetBook(BookName);
			this.numOfPages = new PdfHandler().numOfPages(file.toString());
			LocalConnection.GetNotes(LocalConnection.UserID, LocalConnection.BookID, pageNum);
			WestPanel.Notes.setModel(listModel); 
			//Image.getInstance().addImage(MainFrame.image);
		} catch (Exception e) {}
		return numOfPages;
	}
	public int openFile(){
		try {
			pageNum =0;
			JFileChooser chooser = new JFileChooser();
			FileNameExtensionFilter filter = new FileNameExtensionFilter("PDF","pdf");
			chooser.setFileFilter(filter);
			chooser.setMultiSelectionEnabled(false);
			int returnVal = chooser.showOpenDialog(null);
			if(returnVal == JFileChooser.APPROVE_OPTION) {
				file=chooser.getSelectedFile();
			}
			
			if(LocalConnection.UserID>0){
			BookName = LocalConnection.GetBookName(file.getAbsolutePath());
			LocalConnection.SetBook(BookName , file.getAbsolutePath());
			LocalConnection.BookID = LocalConnection.GetBook(BookName);
			LocalConnection.SetBook( LocalConnection.UserID , LocalConnection.BookID  );
			}
			MainFrame.image = new PdfHandler().convertPDFToJPG(file.toString(),0);
			ImageIcon icon = new ImageIcon(MainFrame.image);
			MainFrame.label.setIcon(icon);
			this.numOfPages = new PdfHandler().numOfPages(file.toString());
			//Image.getInstance().addImage(MainFrame.image);
		} catch (Exception e) {}
		return numOfPages;
	}
	public void viewNextPage(){
		try {
			 pageNum++;
			 MainFrame.image = new PdfHandler().convertPDFToJPG(file.toString(), pageNum);
			ImageIcon icon = new ImageIcon(MainFrame.image);
			MainFrame.label.setIcon(icon);
		setChanged();
		notifyObservers();

		LocalConnection.GetNotes(LocalConnection.UserID, LocalConnection.BookID, pageNum);
		WestPanel.Notes.setModel(listModel);
		stopSpeaking();
		applyZoom(sliderValue);
		//Image.getInstance().addImage(MainFrame.image);
		} catch (Exception e) {System.out.print(e);}
	}
	public void viewLastPage(){
		try {
			pageNum--;
			MainFrame.image = new PdfHandler().convertPDFToJPG(file.toString(),pageNum);
			ImageIcon icon = new ImageIcon(MainFrame.image);
			MainFrame.label.setIcon(icon);
			setChanged();
			notifyObservers();
			LocalConnection.GetNotes(LocalConnection.UserID, LocalConnection.BookID, pageNum);
			WestPanel.Notes.setModel(listModel); 
			stopSpeaking();
			applyZoom(sliderValue);
			//Image.getInstance().addImage(MainFrame.image);
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
	}
	public void beginSpeaking(){
		if (!isSpeaking) {
			try {
				PdfHandler PdfHandler = new PdfHandler();
				final String thingToSay = PdfHandler.convertPDFpageToString(file.toString(), pageNum + 1);
				System.out.println(thingToSay);
				speaker = new Speaker("kevin16");

				speakingThread = new Thread(new Thread() {
					@Override
					public void run() {
						speaker.say(thingToSay);
					}
				});
				speakingThread.start();
				isSpeaking = true;
			} catch (Exception e) {
				// TODO Auto-generated catch block
			} 
		}
	}
	public void stopSpeaking(){
		try {
			isSpeaking = false;
			if (speakingThread.isAlive()){
				speaker.dispose();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
	}
	public void gotoPage(int pageNum){
		if(pageNum>numOfPages)
			return;
		this.pageNum = pageNum;
		MainFrame.image = new PdfHandler().convertPDFToJPG(
				file.toString(),pageNum);
		ImageIcon icon = new ImageIcon(MainFrame.image);
		MainFrame.label.setIcon(icon);
		setChanged();
		notifyObservers();
		stopSpeaking();
		applyZoom(sliderValue);
		/*try {
			//Image.getInstance().addImage(MainFrame.image);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	private double sliderValue = 50;
	private double zoomValue = 1;
	public boolean applyZoom(double sliderValue){
		this.sliderValue = sliderValue;
		zoomValue = 51-sliderValue;
		int w = (int) (MainFrame.image.getWidth()/zoomValue);
		int h = (int) (MainFrame.image.getHeight()/zoomValue);
		MainFrame.label.setIcon(new ImageIcon(MainFrame.image.getScaledInstance(w, h, 0)));
		return true;
	}
	public int getPageNum(){
		return pageNum;
	}
}
