import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;


public class MainFrame{
	
	public static JLabel label = new JLabel("");
	public static BufferedImage image;
	public static NorthPanel nPanel;
	public static JFrame frame ;
	public JPanel eastPanel;
	public MainFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//frame.setUndecorated(true);
		frame = new JFrame();
		nPanel = new NorthPanel(frame);
		new SouthPanel(frame);
		
		// frame.getContentPane().add(new JPanel(), BorderLayout.EAST);
		
		eastPanel = new EastPanel();
		frame.getContentPane().add(eastPanel,BorderLayout.EAST);
		
		new ViewArea(frame);
		frame.setBounds(100, 100, 563, 426);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		new MenuBar(frame) {
			@Override
			public void removeEastPanel() {
				frame.getContentPane().remove(eastPanel);
			}

			@Override
			public void showEastPanel() {
				frame.getContentPane().add(eastPanel,BorderLayout.EAST);
			}

			@Override
			public void removeWestPanel() {
				try {
					frame.getContentPane().remove(EastPanel.westPanel);
				} catch (NullPointerException e) {}
			}

			@Override
			public void showWestPanel() {
				try {
					frame.getContentPane().add(EastPanel.westPanel,BorderLayout.WEST);
				} catch (NullPointerException e) {}
			}
		};
		frame.show();
	}
	public static void main(String[] args){
		try {
		    /*for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
		    	System.out.println(info.getClassName());
		        if ("Nimbus".equals(info.getName())) {
		            UIManager.setLookAndFeel(info.getClassName());
		            break;
		        }
		    }*/
			//UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
			UIManager.setLookAndFeel("com.birosoft.liquid.LiquidLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.noire.NoireLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.aero.AeroLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.bernstein.BernsteinLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.fast.FastLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.graphite.GraphiteLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.mint.MintLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.texture.TextureLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.luna.LunaLookAndFeel");
			//UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel ");
			//UIManager.setLookAndFeel("napkin.NapkinLookAndFeel");
		} catch (Exception e) {
		    // If Nimbus is not available, fall back to cross-platform
		    try {
		        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		    } catch (Exception ex) {
		        // not worth my time
		    }
		}
		new MainFrame();
	}
}
