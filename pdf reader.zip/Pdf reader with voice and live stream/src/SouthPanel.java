import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SouthPanel extends JPanel {
	JButton leftButton = new JButton();
	JButton rightButton = new JButton();
	UIActions actions;
	public SouthPanel(JFrame frame) {
		super();
		this.actions = UIActions.getInstance();
		frame.getContentPane().add(this, BorderLayout.SOUTH);
		this.setBackground(Color.WHITE);

		frame.getContentPane().add(this, BorderLayout.SOUTH);
		leftButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actions.viewLastPage();
			}
		});
		// button_1.setBackground(Color.GRAY);
		setBtn("right.png", rightButton, "next page...");
		setBtn("left.png", leftButton, "previos page...");
		this.add(leftButton);
		rightButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actions.viewNextPage();
			}
		});
		// button.setBackground(Color.GRAY);
		this.add(rightButton);
	}

	private void setBtn(String src, JButton btn, String toolTip) {
		btn.setBackground(Color.WHITE);
		Image i = null;
		try {
			i = ImageIO.read(new File(src));
		} catch (IOException e) {
			e.printStackTrace();
		}
		btn.setIcon(new ImageIcon(i.getScaledInstance(20, 25, 0)));
		btn.setToolTipText(toolTip);
	}

	private void setBtn(String src, JButton btn) {
		btn.setBackground(Color.WHITE);
		Image i = null;
		try {
			i = ImageIO.read(new File(src));
		} catch (IOException e) {
			e.printStackTrace();
		}
		btn.setIcon(new ImageIcon(i.getScaledInstance(20, 25, 0)));
	}
}
