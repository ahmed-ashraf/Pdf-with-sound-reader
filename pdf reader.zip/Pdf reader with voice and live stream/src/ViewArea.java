import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class ViewArea extends JScrollPane {
	JScrollPane scrollPane = new JScrollPane();
	public ViewArea(JFrame frame){
		super();
		
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		MainFrame.label.setBackground(Color.WHITE);
		MainFrame.label.setHorizontalAlignment(SwingConstants.CENTER);
		scrollPane.setViewportView(MainFrame.label);
	}
}
