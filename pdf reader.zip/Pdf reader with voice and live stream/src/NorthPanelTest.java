import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

public class NorthPanelTest {

	@Test
	public void stopBtnTest() {
		MainFrame window = new MainFrame();
		UIActions a = UIActions.getInstance();
		a.file = new File("C:\\Users\\ahmed\\Desktop\\docmentation.pdf");
		window.nPanel.btnPlay.doClick();
		window.nPanel.btnStop.doClick();
		assertEquals(a.isSpeaking, false);
	}
	@Test
	public void playBtnTest(){
		MainFrame window = new MainFrame();
		UIActions a = UIActions.getInstance();
		a.file = new File("C:\\Users\\ahmed\\Desktop\\docmentation.pdf");
		window.nPanel.btnPlay.doClick();
		assertEquals(a.isSpeaking, true);
	}
	@Test
	public void textFieldPageTest(){
		MainFrame window = new MainFrame();
		UIActions a = UIActions.getInstance();
		a.file = new File("C:\\Users\\ahmed\\Desktop\\docmentation.pdf");
		a.viewNextPage();
		a.gotoPage(10);
		System.out.println(a.pageNum);
		//assertEquals(window.nPanel.textField.getText(), "10");
		assertEquals(a.pageNum, 1);
	}
}
