import javax.swing.JPanel;
import javax.swing.JPasswordField;

import java.awt.GridBagLayout;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.JButton;

import java.awt.BorderLayout;
import java.awt.Color;


public class EastPanel extends JPanel {
	private JTextField usertextField;
	private JTextField passtextField;
	static LocalConnection.Row r = new LocalConnection.Row();
	public static  JPanel westPanel;
	/**
	 * Create the panel.
	 */
	public EastPanel() {
		setBackground(Color.WHITE);
		
		setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10,new Color(14408667)));
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblUserName = new JLabel("User Name");
		GridBagConstraints gbc_lblUserName = new GridBagConstraints();
		gbc_lblUserName.insets = new Insets(0, 0, 5, 0);
		gbc_lblUserName.gridx = 5;
		gbc_lblUserName.gridy = 2;
		add(lblUserName, gbc_lblUserName);
		
		usertextField = new JTextField();
		GridBagConstraints gbc_usertextField = new GridBagConstraints();
		gbc_usertextField.insets = new Insets(0, 0, 5, 0);
		gbc_usertextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_usertextField.gridx = 5;
		gbc_usertextField.gridy = 3;
		add(usertextField, gbc_usertextField);
		usertextField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		GridBagConstraints gbc_lblPassword = new GridBagConstraints();
		gbc_lblPassword.insets = new Insets(0, 0, 5, 0);
		gbc_lblPassword.gridx = 5;
		gbc_lblPassword.gridy = 4;
		add(lblPassword, gbc_lblPassword);
		
		passtextField = new JPasswordField();
		GridBagConstraints gbc_passtextField = new GridBagConstraints();
		gbc_passtextField.insets = new Insets(0, 0, 5, 0);
		gbc_passtextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_passtextField.gridx = 5;
		gbc_passtextField.gridy = 5;
		add(passtextField, gbc_passtextField);
		passtextField.setColumns(10);
		
		UserUothorizeBtn loginBtn = new UserUothorizeBtn();
		loginBtn.setLogin();
		GridBagConstraints gbc_loginBtn = new GridBagConstraints();
		gbc_loginBtn.gridx = 5;
		gbc_loginBtn.gridy = 6;
		add(loginBtn, gbc_loginBtn);
		loginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!LocalConnection.Login)
				{
				r = LocalConnection.GetUser(usertextField.getText(), passtextField.getText());
				
				if(usertextField.getText().equals(r.Name) && passtextField.getText().equals(r.Password))
				{
					loginBtn.setLogout();
					LocalConnection.UserID = Integer.parseInt(r.ID);
					LocalConnection.Login=true;
					//MainFrame.eastPanel.setVisible(false);
					westPanel = new WestPanel();
					MainFrame.frame.getContentPane().add(westPanel,BorderLayout.WEST);
					
				}
          else  JOptionPane.showMessageDialog(null, "Invalid User Name OR Password");
			}
		
		else{
			LocalConnection.Login=false;
			westPanel.removeAll();
			MainFrame.frame.getContentPane().remove(westPanel);
			loginBtn.setLogin(); }
			
			}});
		
		
		JButton registerBtn = new JButton("Register");
		GridBagConstraints gbc_registerBtn = new GridBagConstraints();
		gbc_registerBtn.gridx = 5;
		gbc_registerBtn.gridy = 7;
		add(registerBtn, gbc_registerBtn);
		registerBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Register Note =new Register();
				Note.setSize(600,400);
				Note.setResizable(false);
				Note.setVisible(true);
			}
		});
		
	}
	public static void main(String[] a){
		UserUothorizeBtn btn = new UserUothorizeBtn();
		btn.setLogin();
		System.out.println(btn.getText());
		btn.setLogout();
		System.out.println(btn.getText());
		btn.setLogin();
		System.out.println(btn.getText());
		btn.setLogout();
		System.out.println(btn.getText());
	}

}
class UserUothorizeBtn extends JButton{
	BtnState loginState;
	BtnState logoutState;
	
	BtnState state = loginState;
	public UserUothorizeBtn(){
		loginState = new LoginState(this);
		logoutState = new LogoutState(this);
		state = loginState;
	}
	void setState(BtnState state){
		this.state = state;
	}
	public void setLogin(){
		state.login();
	}
	public void setLogout(){
		state.logout();
	}
	public BtnState getState(){
		return state;
	}
	public BtnState loginState(){
		return loginState;
	}
	public BtnState logoutState(){
		return logoutState;
	}
}
interface BtnState{
	public void login();
	public void logout();
}
class LoginState implements BtnState{
	UserUothorizeBtn btn;
	public LoginState(UserUothorizeBtn btn){
		this.btn=btn;
	}
	@Override
	public void login() {
		// TODO Auto-generated method stub
		btn.setText("Log in");
		btn.setState(btn.loginState);
	}

	@Override
	public void logout() {
		// TODO Auto-generated method stub
		btn.setText("Log out");
		btn.setState(btn.logoutState);
	}
	
}
class LogoutState implements BtnState{
	UserUothorizeBtn btn;
	public LogoutState(UserUothorizeBtn btn){
		this.btn=btn;
	}
	@Override
	public void login() {
		// TODO Auto-generated method stub
		btn.setText("Log in");
		btn.setState(btn.loginState);
	}

	@Override
	public void logout() {
		// TODO Auto-generated method stub
		btn.setText("Log out");
		btn.setState(btn.logoutState);
	}
	
}
