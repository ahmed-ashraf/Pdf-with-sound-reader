import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;

public class Image {
	private static Image instance = null;
	private  Connection con;
	private  Statement st;
	private  ResultSet rs = null;
	/*public static void main(String[] s) throws SQLException, IOException{
		Image.getInstance().addImage(new BufferedImage(100, 100, 1));
	}*/
	
	private Image(){
		DBConnect();
	}
	public static synchronized Image getInstance(){
		if(instance == null) {
	         instance = new Image();
	      }
	      return instance;
	}
	private  void DBConnect(){
    	try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/databaseimage","root","");
            st = con.createStatement();
            //System.out.println("ddd");
        } catch (Exception ex) {
        	System.out.println("Error: "+ex);
        }
    }
	public int addImage(BufferedImage image) throws SQLException, IOException{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write( image, "png", baos );
		baos.flush();
		byte[] imageInByte = baos.toByteArray();
		baos.close();
		Blob blob = new javax.sql.rowset.serial.SerialBlob(imageInByte);
    	PreparedStatement pstmt = con.prepareStatement(
                "UPDATE `databaseimage`.`store` SET `Image` =? WHERE `store`.`ID` = 1");
    	pstmt.setBlob(1, blob);
    	//System.out.println(pstmt);
    	int checkResult = 0;
		try {
			checkResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return checkResult;
    }
}
