import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class NorthPanel implements Observer {
	private JButton btnOpenFile = new JButton();
	JTextField textField = new JTextField();
	JButton btnPlay = new JButton("play");
	JButton btnStop = new JButton();
	private JLabel lblNewLabel = new JLabel("Page");
	private JSlider slider = new JSlider();
	int pageNum=0;
	UIActions actions ;
	
	public NorthPanel(JFrame frame){
		this.actions= UIActions.getInstance();
		actions.addObserver(this);
		//actions = new UIActions(this);
		//actions = new UIActions(this);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		slider.setBackground(Color.LIGHT_GRAY);
		slider.setMaximum(50);
		slider.setMinimum(35);
		
		
		slider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				try {
					actions.applyZoom(slider.getValue());
				} catch (Exception e1) {}
			}
		});
		//btnOpenFile.setBackground(Color.LIGHT_GRAY);
		btnOpenFile.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				actions.openFile();
			}
		});
		panel.add(btnOpenFile);
		panel.add(slider);
		btnPlay.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				actions.beginSpeaking();
			}
		});
		btnStop.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				actions.stopSpeaking();
			}
		});
		
		textField.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s = textField.getText();
				int i = Integer.parseInt(s);
				//pageNum=i;
				//setChanged();
				//notifyObservers();
				// System.out.println(pageNum);
				actions.gotoPage(i);
			}
		});
		textField.setText(Integer.toString(pageNum));
		textField.setColumns(10);
		
		setBtn("stop.png", btnStop, "Stop...");
		setBtn("document_open.png", btnOpenFile, "Open File...");
		setBtn("speaker.png",btnPlay,"Speak...");
		panel.setBackground(Color.WHITE);
		slider.setBackground(Color.WHITE);
		panel.add(btnPlay);
		panel.add(btnStop);
		panel.add(lblNewLabel);
		panel.add(textField);
	}
	
	/*public int getPageNum(){
		return 0;
	}*/
	
	
	private void setBtn(String src,JButton btn,String toolTip){
		btn.setBackground(Color.WHITE);
		Image i = null;
		try {
			i = ImageIO.read(new File(src));
		} catch (IOException e) {
			e.printStackTrace();
		}
		btn.setIcon(new ImageIcon(i.getScaledInstance(20, 25, 0)));
		btn.setToolTipText(toolTip);
	}
	private void setBtn(String src,JButton btn){
		btn.setBackground(Color.WHITE);
		Image i = null;
		try {
			i = ImageIO.read(new File(src));
		} catch (IOException e) {
			e.printStackTrace();
		}
		btn.setIcon(new ImageIcon(i.getScaledInstance(20, 25, 0)));
	}

	@Override
	public void update(Observable o, Object arg1) {
		// TODO Auto-generated method stub
		if(o instanceof UIActions){
			this.pageNum=((UIActions) o).getPageNum();
			textField.setText(Integer.toString(pageNum));
		}
	}

	
}
