import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public  class NoteContent extends JFrame{
		
	 JLabel RegisterHeading = new JLabel("Note");
	 TextArea Note = new TextArea();
	 JButton Close = new JButton( "Close" );
		public NoteContent(){
			super( "Note" );
			setLayout(null);
			
			 RegisterHeading.setBounds(230,30,400,26);
			 RegisterHeading.setForeground(Color.WHITE);
			 RegisterHeading.setFont(new Font("andalus", Font.PLAIN, 26));
			add(RegisterHeading);
					
			
			Note.setBounds(20,100,540,200);
			Note.setForeground(Color.black);
			Note.setFont(new Font("andalus", Font.PLAIN, 18));
			Note.setEnabled(false);
			add(Note);
			
			Close.setBounds(230,320,120,35);
			Close.setBackground(new Color(95,95,95));
			Close.setForeground(Color.WHITE);
			Close.setFont(new Font("andalus", Font.PLAIN, 24));
			add(Close);

			
			 getContentPane().setBackground(Color.DARK_GRAY);
				
			Close.addActionListener( new ActionListener() {public void actionPerformed(ActionEvent arg0) {
				dispose();
			}});
					
			
		}
		}