import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class WestPanel extends JPanel {
	JList History;
	public static JList Notes = new JList();
	ListModel model = Notes.getModel();

	static List<LocalConnection.Book> B;
	static String[] books;

	private UIActions actions = UIActions.getInstance();

	public WestPanel() {
		setBackground(Color.WHITE);
		setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10, new Color(14408667)));
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0 };
		gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		setLayout(gridBagLayout);

		int countr = 0;
		B = LocalConnection.GetBook(LocalConnection.UserID);
		books = new String[B.size()];
		for (LocalConnection.Book b : B) {
			books[countr] = b.Name;
			countr++;
		}

		History = new JList(books);

		History.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent evt) {
				if (!evt.getValueIsAdjusting()) {
					JList source = (JList) evt.getSource();
					String Name = source.getSelectedValue().toString();
					String path = LocalConnection.GetBookPath(Name);
					MainFrame.nPanel.textField.setText("0");
					actions.openFile(path);

					// code here
				}
			}
		});

		Notes.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent evt) {
				if (!evt.getValueIsAdjusting()) {
					JList source = (JList) evt.getSource();
					String Heading = source.getSelectedValue().toString();
					
					String Note = LocalConnection.GetNote(LocalConnection.UserID, LocalConnection.BookID,
							UIActions.pageNum, Heading);
					NoteContent N = new NoteContent();
					N.setSize(600, 400);
					N.setResizable(false);
					N.setVisible(true);
					N.Note.setText(Note);
					N.RegisterHeading.setText(Heading);
				}
			}
		});

		JLabel Heading = new JLabel("  Books History  ");
		Heading.setForeground(Color.BLACK);
		Heading.setFont(new Font("andalus", Font.PLAIN, 22));
		GridBagConstraints gbc_Heading = new GridBagConstraints();
		gbc_Heading.gridx = 5;
		gbc_Heading.gridy = 1;
		add(Heading, gbc_Heading);

		History.setBackground(Color.ORANGE);
		GridBagConstraints gbc_passtextField = new GridBagConstraints();
		gbc_passtextField.insets = new Insets(0, 0, 5, 0);
		gbc_passtextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_passtextField.gridx = 5;
		gbc_passtextField.gridy = 2;
		add(History, gbc_passtextField);

		JLabel HeadingNotes = new JLabel("  Book Notes  ");
		HeadingNotes.setForeground(Color.BLACK);
		HeadingNotes.setFont(new Font("andalus", Font.PLAIN, 22));
		GridBagConstraints gbc_HeadingNotes = new GridBagConstraints();
		gbc_HeadingNotes.gridx = 5;
		gbc_HeadingNotes.gridy = 3;
		add(HeadingNotes, gbc_HeadingNotes);

		Notes.setBackground(new Color(45, 124, 154));
		GridBagConstraints gbc_Notes = new GridBagConstraints();
		gbc_Notes.insets = new Insets(0, 0, 5, 0);
		gbc_Notes.fill = GridBagConstraints.HORIZONTAL;
		gbc_Notes.gridx = 5;
		gbc_Notes.gridy = 4;
		add(Notes, gbc_Notes);

		JButton AddNote = new JButton("Add Note");
		GridBagConstraints gbc_AddNote = new GridBagConstraints();
		gbc_AddNote.gridx = 5;
		gbc_AddNote.gridy = 6;
		add(AddNote, gbc_AddNote);

		AddNote.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				Note Note = new Note();
				Note.setSize(600, 400);
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				Note.setLocation(dim.width/2-Note.getSize().width/2, dim.height/2-Note.getSize().height/2);
				Note.setVisible(true);
				Note.setResizable(false);
			}
		});

	}

}
