import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class LocalConnection {
	
	public static String RegistrationName = "";
	
	private static final String USERNAME = "root";
	private static final String PASSWORD = "";
	private static final String CONN_STRING ="jdbc:mysql://localhost:3306/pdf_reader?autoReconnect=true&useSSL=false";
	
	static Connection Con = null;
	static Statement Stm = null; 
	static ResultSet Rs = null; 
	static ResultSet Rss = null; 
	static PreparedStatement Ps = null;

	static int UserID = 0;
	static int BookID ;
	static boolean Login = false;
	public static boolean  SetUser( String UserName , String UserPassword )
	{
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			
			Ps = Con.prepareStatement("INSERT INTO user (Name , Password ) VALUES (?,?)" );

			Ps.setString( 1, UserName );
			Ps.setString( 2, UserPassword );

			Ps.executeUpdate();
			return true;
	         } 
	catch (SQLException e) {System.out.println(e);  return false;} finally {try {Rs.close();Stm.close();Con.close();} catch ( Exception exception ){}}
	}
 	public static boolean  SetBook( String BookName,String BookPath )
	{
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			
			Ps = Con.prepareStatement("INSERT INTO Book (Name , Path ) VALUES (?,?)" );
			Ps.setString( 1, BookName );
			Ps.setString( 2, BookPath );
try{
			Ps.executeUpdate();}catch(Exception e){}
			return true;
	         } 
	catch (SQLException e) {System.out.println(e);return false;} finally {try {Rs.close();Stm.close();Con.close();} catch ( Exception exception ){}}
	}
 	
 	public static boolean  SetBook( int UserID , int BookID )
	{
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			
			Ps = Con.prepareStatement("INSERT INTO userbook (UserID , BookID ) VALUES (?,?)" );

			Ps.setInt( 1, UserID );
			Ps.setInt( 2, BookID );

			Ps.executeUpdate();
			return true;
	         } 
	catch (SQLException e) {System.out.println(e);  return false;} finally {try {Rs.close();Stm.close();Con.close();} catch ( Exception exception ){}}
	}
 	
 	public static boolean  SetUser( String User , String Pass ,String Question ,String Answer)
	{
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			
			Ps = Con.prepareStatement("INSERT INTO Book (Name , Password ,Question , Answer) VALUES (?, ?, ?, ?)" );
			if(User .equals("") || Pass .equals("") || Question .equals("") || Answer .equals("") ){
				JOptionPane.showMessageDialog( null ,"There Is Empty Field , ReFill Data !!!");
				return false;
			}
			else{
			Ps.setString( 1, User );
			Ps.setString( 2, Pass );
			Ps.setString( 3, Question );
			Ps.setString( 4, Answer );
			Ps.executeUpdate();
			JOptionPane.showMessageDialog( null ,"Data Commpletely Saved !!!"); 
			return true;
			} 
	         } 
	catch (SQLException e) {System.out.println(e); JOptionPane.showMessageDialog( null ," This User Name Exist !!!"); return false;} finally {try {Rs.close();Stm.close();Con.close();} catch ( Exception exception ){}}
	}
 	
 	public static boolean  SetNote( int UserID , int BookID , int PageNumber ,String Heading ,String Note )
	{
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			
			Ps = Con.prepareStatement("INSERT INTO Notes (UserID , BookID , PageNumber, Headline , Note ) VALUES (?,?,?,?,?)" );

			Ps.setInt( 1, UserID );
			Ps.setInt( 2, BookID );
			Ps.setInt( 3, PageNumber );
			Ps.setString( 4, Heading );
			Ps.setString( 5, Note );
			Ps.executeUpdate();
			return true;
	         } 
	catch (SQLException e) {System.out.println(e);  return false;} finally {try {Rs.close();Stm.close();Con.close();} catch ( Exception exception ){}}
	}

	public static class Row 
	{
		static String ID = null;  
		static String Name = null;  
		static String Password = null;  
	}

	public static  class Book 
	{
		 int ID = 0;  
		 String Name = null;  
		 String Description = null;  
		  String Author = null; 
		 int Price = 0;  
	}

	public static class note {
		String Head ;
		String Note;
	}

	public static Row GetUser(String Name)
	{
		Row R = null;

		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Rs = Stm.executeQuery("SELECT Name , password FROM User " );
			
			while(Rs.next())
			{
				if(Rs.getString("Name").equals(Name))
				{
					R.Name = Rs.getString("Name");
					R.Password = Rs.getString("password");
					break;
				}
				
			}
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return R;
	}
	
	public static Row DeleteUser(String Name)
	{
		Row R = null;

		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Ps = Con.prepareStatement("Delete from  user where Name = '"+Name+"'");
			Ps.executeUpdate();
			
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return R;
	}

	public static Row UpdateUser(String OldName , String Name ,String Pass ,String Question ,String Answer  )
	{
		Row R = null;

		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			String sql = " update user set  Name = '"+Name+"',Password ='"+Pass+"' ,Question = '"+Question+" ' , Answer = ' "+Answer+"'  where Name = '"+OldName+"'" ;
		      Ps = Con.prepareStatement(sql);
		      Ps.executeUpdate();
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return R;
	}

	public static Row GetUser(String Name , String Password)
	{
		Row R = null;

		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Rs = Stm.executeQuery("SELECT ID , Name ,  password FROM User " );
			
			while(Rs.next())
			{
				if(Rs.getString("Name").equals(Name) && Rs.getString("password").equals(Password))
				{
					R.ID = Rs.getString("ID");
					R.Name = Rs.getString("Name");
					R.Password = Rs.getString("password");
					break;
				}
				
			}
			
			
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return R;
	}

	public static List<Book> GetBook(int ID)
	{
		List<Book> B = new ArrayList<Book>();
		
		
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Rs = Stm.executeQuery("Select  B.ID ,  B.Name , B.Description , B.Author , B.Price  From   Book B , userbook C   Where   C. UserID = "+ ID +" And    B. ID = C. BookID " );
			
			while(Rs.next())
			{
				Book b = new Book();
				b.ID = Rs.getInt("ID");
				b.Name = Rs.getString("Name");
				b.Description = Rs.getString("Description");
				b.Author = Rs.getString("Author");
				b.Price = Rs.getInt("Price");
				
				B.add(b);
			}
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return B;
	}

	public static int GetBook(String BookName)
	{
		int BookID = 0;
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Rs = Stm.executeQuery("Select  ID  From   Book    Where    Name = '"+ BookName+"'"  );
			Rs.next();
			BookID = Rs.getInt("ID");
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return BookID;
	}

	public static boolean GetNotes(int UserID ,int BookID , int PageNumber)
	{
		UIActions.listModel = new DefaultListModel<>();
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Rs = Stm.executeQuery("Select  Headline From   Notes    Where    UserID = '"+ UserID+"' And BookID = '" + BookID+"' And PageNumber =  '"+ PageNumber+"'" );
			while(Rs.next()){
				UIActions.listModel.addElement(Rs.getString("Headline"));
		    }
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return true;
	}
	
	public static String GetNote(int UserID ,int BookID , int PageNumber , String Heading)
	{
		String Note="";
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Rs = Stm.executeQuery("Select  Note From   Notes    Where    UserID = '"+ UserID+"' And BookID = '" + BookID+"' And PageNumber =  '"+ PageNumber +"' And Headline =  '"+ Heading+"'" );
			Rs.next();
			Note=Rs.getString("Note");

		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return Note;
	}

	public static String GetBookName(String Path)
	{
	 char[] path = Path.toCharArray();
	 int Strt = 0;
	 int End = path.length;
	 for (int i = 0; i < path.length; i++)  if(path[i]==92) Strt = i+1 ;

	 return Path.substring(Strt, End);
	}

	public static String GetBookPath(String BookName)
	{
		String path=null;
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();
			Rs = Stm.executeQuery("Select  Path  From   Book    Where    Name = '"+ BookName+"'"  );
			Rs.next();
			path = Rs.getString("Path");
		}catch (SQLException e) {System.err.println(e);
		} finally {  try {Rs.close(); Stm.close();Con.close();} catch ( Exception exception ){exception.printStackTrace();}}
		return path;
	}

	public static  boolean Remove(String Note_Name) {
		try {
			Con = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
			Stm = Con.createStatement();

			Stm.executeUpdate("DELETE FROM notes WHERE Headline ='" + Note_Name+"'") ;
			Rs = Stm.executeQuery("Select * from notes WHERE Headline='" + Note_Name+"'");
			if (Rs.next()) {
				Stm.close();
				Con.close();
				return false;
			} else {
				Stm.close();
				Con.close();
				return true;
			}
		} catch (SQLException ex) {
			Logger.getLogger(LocalConnection.class.getName()).log(Level.SEVERE, null, ex);
		}
		return false;

	}
}
