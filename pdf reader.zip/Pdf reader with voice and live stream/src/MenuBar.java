import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;

public abstract class MenuBar extends JMenuBar{
	private JMenu menu;
	private JMenu menuView;
	private JMenu menuHelp;
	private JMenuItem menuItemOpenFile;
	
	private JMenuItem menuItemTips;
	private JMenuItem menuItemContact;
	private JMenuItem menuItemShowMyBooks;
	private JMenuItem menuItemShowNotes;
	private UIActions actions;
	private boolean isEastHidden = false;
	private boolean isWestHidden = false;
	public MenuBar(JFrame frame){
		super();
		this.actions = UIActions.getInstance();
		menuHelp = new JMenu("Help");
		menu = new JMenu("File");
		menuView = new JMenu("View");
		menuItemOpenFile = new JMenuItem("Open File");
		menuItemTips = new JMenuItem("Show tips");
		menuItemContact = new JMenuItem("Contact us");
		menuItemShowNotes = new JCheckBoxMenuItem("My Notes");
		menuItemShowMyBooks = new JCheckBoxMenuItem("My books");
		menuItemShowNotes.setSelected(true);
		menuItemShowMyBooks.setSelected(true);
		frame.setJMenuBar(this);
		this.add(menu);
		this.add(menuHelp);
		this.add(menuView);
		menuView.add(menuItemShowMyBooks);
		menuView.add(menuItemShowNotes);
		menu.add(menuItemOpenFile);
		menuHelp.add(menuItemTips);
		//menuHelp.add(menuItemContact);
		menuItemOpenFile.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actions.openFile();
			}
		});
		menuItemShowMyBooks.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!isEastHidden) {
					removeEastPanel();
					SwingUtilities.updateComponentTreeUI(frame);
					isEastHidden = true;
				}else{
					showEastPanel();
					SwingUtilities.updateComponentTreeUI(frame);
					isEastHidden = false;
				}
			}
		});
		menuItemShowNotes.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(isWestHidden){
					showWestPanel();
					SwingUtilities.updateComponentTreeUI(frame);
					isWestHidden = false;
				}else{
					removeWestPanel();
					SwingUtilities.updateComponentTreeUI(frame);
					isWestHidden = true;
				}
			}
		});
		menuItemTips.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JFrame frame =new UserHelperFrame();
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				frame.setLocation(dim.width/2-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
				frame.setVisible(true);
			}
		});
	}
	
	public abstract void removeEastPanel();
	public abstract void showEastPanel();
	public abstract void removeWestPanel();
	public abstract void showWestPanel();
}
