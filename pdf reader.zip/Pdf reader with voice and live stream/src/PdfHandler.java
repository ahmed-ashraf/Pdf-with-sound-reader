

import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class PdfHandler{
	public BufferedImage convertPDFToJPG(String src,int pageNum){
		BufferedImage bi = null;
		PDDocument doc = null;
		try {
			doc = PDDocument.load(new FileInputStream(src));
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
		} catch (IOException e) {
			//e.printStackTrace();
		}
		@SuppressWarnings("unchecked")
		ArrayList<PDPage> pages=(ArrayList<PDPage>) doc.getDocumentCatalog().getAllPages();
		PDPage page=pages.get(pageNum);
		try {
			bi=page.convertToImage();
		} catch (IOException e) {
			//e.printStackTrace();
		}
		return bi;
	}
	public int numOfPages(String src){
		PDDocument doc = null;
		try {
			doc = PDDocument.load(new FileInputStream(src));
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
		} catch (IOException e) {
			//e.printStackTrace();
		}
		@SuppressWarnings("unchecked")
		ArrayList<PDPage> pages=(ArrayList<PDPage>) doc.getDocumentCatalog().getAllPages();
		
		return pages.size();
	}
	public String convertPDFpageToString(String src,int pageNum){
		PdfReader pr;
		String s = null;
		try {
			pr = new PdfReader(src);
			s=PdfTextExtractor.getTextFromPage(pr, pageNum);
		} catch (IOException e) {
			//e.printStackTrace();
		}
		return s;
	}
}